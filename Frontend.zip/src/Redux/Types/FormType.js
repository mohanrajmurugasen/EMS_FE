export const FormType = {
  FORMCOUNT: 'FORMCOUNT',
  FORMVALUE: 'FORMVALUE',
  FORMALL: 'FORMALL',
}
